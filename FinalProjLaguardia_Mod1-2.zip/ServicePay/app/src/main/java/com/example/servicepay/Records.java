package com.example.servicepay;

public class Records {
    String fullname;
    String mobilenumber;
    String emailaddress;

    Records(){ }
    public Records(String fullname, String mobilenumber, String emailaddress) {
        this.fullname = fullname;
        this.mobilenumber = mobilenumber;
        this.emailaddress = emailaddress;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getMobilenumber() {
        return mobilenumber;
    }

    public void setMobilenumber(String mobilenumber) {
        this.mobilenumber = mobilenumber;
    }

    public String getEmailaddress() {
        return emailaddress;
    }

    public void setEmailaddress(String emailaddress) {
        this.emailaddress = emailaddress;
    }

}
