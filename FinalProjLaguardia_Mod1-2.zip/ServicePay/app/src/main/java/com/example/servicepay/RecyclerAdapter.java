package com.example.servicepay;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private Context context;
    ArrayList<Records> list = new ArrayList<>();
    public RecyclerAdapter(Context ctx){
        this.context = ctx;
    }
    public void setItems(ArrayList<Records> rec) {
        list.addAll(rec);
    }
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.layout_item,parent,false);
        return new RecordsVH(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        RecordsVH vh = (RecordsVH) holder;
        Records rec = list.get(position);
        vh.txt_name.setText(rec.getFullname());
        vh.txt_mobilenum.setText(rec.getMobilenumber());
        vh.txt_emailadd.setText(rec.getEmailaddress());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}
